#!/bin/bash
# ============================================================
# LAB: Gestão de Memória no Linux - Script 3
# Tópico: Substituição de Páginas (Page Replacement)
# ============================================================

echo "======================================================"
echo " LABORATÓRIO: SUBSTITUIÇÃO DE PÁGINAS"
echo "======================================================"
echo ""

# --- 1. Política LRU activa ---
echo "[1] Política de substituição activa no kernel"
echo "------------------------------------------------------"
echo "  O Linux usa uma variante de LRU com duas listas (activa/inactiva)"
echo ""
grep -E "nr_active_anon|nr_inactive_anon|nr_active_file|nr_inactive_file|nr_unevictable" /proc/vmstat | \
  awk '{printf "  %-35s %d páginas\n", $1, $2}'
echo ""

# --- 2. Tamanho de página ---
echo "[2] Tamanho de página do sistema"
echo "------------------------------------------------------"
PAGE_SIZE=$(getconf PAGESIZE)
echo "  Tamanho de página (PAGESIZE) = $PAGE_SIZE bytes = $(echo "$PAGE_SIZE/1024" | bc) KB"
echo ""
echo "  Huge Pages configuradas:"
grep -E "HugePages_Total|HugePages_Free|Hugepagesize" /proc/meminfo | awk '{printf "  %-25s %s\n", $1, $2" "$3}'
echo ""

# --- 3. Mapa de páginas de um processo ---
echo "[3] Detalhes de paginação de um processo (bash PID: $$)"
echo "------------------------------------------------------"
echo "  Páginas por região de memória:"
awk '{
    perm=$2; size=$3; offset=$4;
    if (NF>=6) name=$NF; else name="[anon]"
    printf "  %-40s perm=%-6s\n", name, perm
}' /proc/$$/maps | sort -u | head -20
echo "  ..."
echo ""

# --- 4. Estatísticas de page cache ---
echo "[4] Page Cache - eficiência"
echo "------------------------------------------------------"
echo "  O Linux mantém um page cache para reduzir acessos a disco"
grep -E "Cached:|Buffers:|Active\(file\)|Inactive\(file\)" /proc/meminfo | \
  awk '{printf "  %-25s %s %s\n", $1, $2, $3}'
echo ""

# --- 5. Limpar page cache (requer sudo) ---
echo "[5] Demonstração: Impacto de limpar o page cache"
echo "------------------------------------------------------"
echo "  ANTES de limpar o cache:"
time find /usr/bin -name '*.py' -exec cat {} \; > /dev/null 2>&1
echo "  Memória usada:"
free -m | grep Mem

echo ""
echo "  Para limpar o page cache, execute (requer sudo):"
echo "    sudo sh -c 'sync; echo 3 > /proc/sys/vm/drop_caches'"
echo "  Depois execute novamente o find e compare o tempo."
echo ""

# --- 6. Simular sequência de referência e calcular page faults (FIFO/LRU) ---
echo "[6] Simulação de algoritmos de substituição (Python)"
echo "------------------------------------------------------"

python3 << 'PYEOF'
def fifo(pages, frames):
    memory, faults, queue = [], 0, []
    for p in pages:
        if p not in memory:
            faults += 1
            if len(memory) < frames:
                memory.append(p)
                queue.append(p)
            else:
                evict = queue.pop(0)
                memory[memory.index(evict)] = p
                queue.append(p)
    return faults

def lru(pages, frames):
    memory, faults, recent = [], 0, []
    for p in pages:
        if p not in memory:
            faults += 1
            if len(memory) < frames:
                memory.append(p)
            else:
                evict = recent[0]
                for r in recent:
                    if r in memory:
                        evict = r
                        break
                memory[memory.index(evict)] = p
                if evict in recent: recent.remove(evict)
        else:
            if p in recent: recent.remove(p)
        recent.append(p)
    return faults

def optimal(pages, frames):
    memory, faults = [], 0
    for i, p in enumerate(pages):
        if p not in memory:
            faults += 1
            if len(memory) < frames:
                memory.append(p)
            else:
                future = {}
                for m in memory:
                    try: future[m] = pages[i+1:].index(m)
                    except: future[m] = float('inf')
                evict = max(future, key=future.get)
                memory[memory.index(evict)] = p
    return faults

# Sequência de referência clássica
ref = [7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1]
frames = 3

print(f"  Sequência de referência: {ref}")
print(f"  Número de frames: {frames}")
print()
print(f"  {'Algoritmo':<15} {'Page Faults':<15}")
print(f"  {'-'*30}")
print(f"  {'FIFO':<15} {fifo(ref, frames):<15}")
print(f"  {'LRU':<15} {lru(ref, frames):<15}")
print(f"  {'Óptimo':<15} {optimal(ref, frames):<15}")
print()
print("  NOTA: O algoritmo Óptimo é a referência teórica (não implementável)")
PYEOF

echo ""
echo "======================================================"
echo " [EXERCÍCIO 3] Tarefas práticas:"
echo "======================================================"
echo "  a) Modifique a sequência de referência no script Python"
echo "     e observe como muda o número de page faults"
echo "  b) Aumente o número de frames para 4 e compare resultados"
echo "  c) Explique a 'Anomalia de Bélády' e quando ocorre no FIFO"
echo "  d) Verifique a swappiness do seu sistema:"
echo "     cat /proc/sys/vm/swappiness"
echo "  e) O que acontece se mudar a swappiness para 0 vs 100?"
echo "     sudo sysctl vm.swappiness=10"
echo "======================================================"
