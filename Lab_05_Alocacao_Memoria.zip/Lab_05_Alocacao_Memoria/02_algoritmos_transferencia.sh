#!/bin/bash
# ============================================================
# LAB: Gestão de Memória no Linux - Script 2
# Tópico: Algoritmos de Transferência (Swap / Paging)
# ============================================================

echo "======================================================"
echo " LABORATÓRIO: ALGORITMOS DE TRANSFERÊNCIA"
echo "======================================================"
echo ""

# --- 1. Estado actual do swap ---
echo "[1] Estado do Swap"
echo "------------------------------------------------------"
swapon --show 2>/dev/null || echo "  Nenhum swap activo."
echo ""
free -h | grep -E "Mem|Swap"
echo ""

# --- 2. Actividade de paginação em tempo real ---
echo "[2] Actividade de paginação (vmstat 1 5 - 5 amostras)"
echo "------------------------------------------------------"
echo "  Colunas importantes: si=swap-in, so=swap-out, bi=block-in, bo=block-out"
echo "  pi=page-in, po=page-out"
echo ""
vmstat 1 5
echo ""

# --- 3. Estatísticas detalhadas de paginação ---
echo "[3] Contadores de paginação (/proc/vmstat)"
echo "------------------------------------------------------"
printf "  %-30s %s\n" "Métrica" "Valor"
printf "  %-30s %s\n" "------" "-----"
for metric in pgpgin pgpgout pswpin pswpout pgfault pgmajfault; do
    val=$(grep "^$metric " /proc/vmstat | awk '{print $2}')
    printf "  %-30s %s\n" "$metric" "${val:-N/A}"
done
echo ""

# --- 4. Overcommit ---
echo "[4] Política de Overcommit de Memória"
echo "------------------------------------------------------"
oc=$(cat /proc/sys/vm/overcommit_memory)
or=$(cat /proc/sys/vm/overcommit_ratio)
echo "  overcommit_memory = $oc"
case $oc in
  0) echo "  → Modo: Heurístico (kernel decide se aprova alocações grandes)" ;;
  1) echo "  → Modo: Sempre aprova (permite alocação além da RAM+Swap)" ;;
  2) echo "  → Modo: Nunca excessivo (limita ao overcommit_ratio% da RAM)" ;;
esac
echo "  overcommit_ratio  = $or% da RAM física"
echo ""

# --- 5. OOM Killer ---
echo "[5] OOM Killer - pontuações dos processos"
echo "------------------------------------------------------"
echo "  (Processos com oom_score mais alto são candidatos a matar primeiro)"
for pid in $(ls /proc | grep '^[0-9]' | head -20); do
    name=$(cat /proc/$pid/comm 2>/dev/null)
    score=$(cat /proc/$pid/oom_score 2>/dev/null)
    [ -n "$score" ] && [ "$score" -gt 0 ] && echo "  PID $pid ($name): $score"
done 2>/dev/null | sort -t: -k2 -rn | head -10
echo ""

# --- 6. Simular pressão de memória com dd e verificar swap ---
echo "[6] Verificar se swap está a ser usado durante operação intensiva"
echo "------------------------------------------------------"
echo "  Antes:"
free -m | grep -E "Mem|Swap"
echo "  Alocando 100MB temporário com dd..."
dd if=/dev/urandom bs=1M count=100 2>/dev/null | md5sum > /dev/null
echo "  Depois:"
free -m | grep -E "Mem|Swap"
echo ""

echo "======================================================"
echo " [EXERCÍCIO 2] Responda às seguintes questões:"
echo "======================================================"
echo "  a) O que significam pgfault vs pgmajfault?"
echo "  b) Qual a diferença entre swap-in e swap-out?"
echo "  c) Em que situação o OOM Killer é activado?"
echo "  d) O que acontece com overcommit_memory=1?"
echo "  e) Altere o overcommit_ratio para 80% e verifique o efeito:"
echo "     sudo sysctl vm.overcommit_ratio=80"
echo "======================================================"
