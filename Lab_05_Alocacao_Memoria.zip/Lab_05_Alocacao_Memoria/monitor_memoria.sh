#!/bin/bash
# ============================================================
# LAB: Gestão de Memória - Monitor em Tempo Real
# Uso: ./monitor_memoria.sh [intervalo_segundos]
# ============================================================

INTERVAL=${1:-2}
LOG_FILE="/tmp/lab_memoria_$(date +%Y%m%d_%H%M%S).csv"

# Cabeçalho CSV
echo "timestamp,mem_total_mb,mem_used_mb,mem_free_mb,mem_available_mb,swap_used_mb,pgfault,pgmajfault,pswpin,pswpout" > "$LOG_FILE"

echo "======================================================"
echo "  MONITOR DE MEMÓRIA EM TEMPO REAL"
echo "  Intervalo: ${INTERVAL}s | Ctrl+C para parar"
echo "  Log: $LOG_FILE"
echo "======================================================"
printf "\n%-20s %-12s %-12s %-12s %-10s %-10s\n" "Timestamp" "Usada(MB)" "Livre(MB)" "Dispon(MB)" "SwapUsado" "PgFaults"
printf "%-20s %-12s %-12s %-12s %-10s %-10s\n" "─────────────────" "─────────" "──────────" "──────────" "─────────" "────────"

prev_fault=$(grep "^pgfault " /proc/vmstat | awk '{print $2}')

while true; do
    ts=$(date +"%Y-%m-%d %H:%M:%S")
    
    # Ler /proc/meminfo
    mem_total=$(awk '/^MemTotal/ {print int($2/1024)}' /proc/meminfo)
    mem_free=$(awk '/^MemFree/ {print int($2/1024)}' /proc/meminfo)
    mem_avail=$(awk '/^MemAvailable/ {print int($2/1024)}' /proc/meminfo)
    mem_used=$((mem_total - mem_avail))
    swap_total=$(awk '/^SwapTotal/ {print int($2/1024)}' /proc/meminfo)
    swap_free=$(awk '/^SwapFree/ {print int($2/1024)}' /proc/meminfo)
    swap_used=$((swap_total - swap_free))
    
    # Ler /proc/vmstat
    pgfault=$(grep "^pgfault " /proc/vmstat | awk '{print $2}')
    pgmajfault=$(grep "^pgmajfault " /proc/vmstat | awk '{print $2}')
    pswpin=$(grep "^pswpin " /proc/vmstat | awk '{print $2}')
    pswpout=$(grep "^pswpout " /proc/vmstat | awk '{print $2}')
    
    # Delta de page faults
    delta_fault=$((pgfault - prev_fault))
    prev_fault=$pgfault
    
    printf "%-20s %-12s %-12s %-12s %-10s %-10s\n" \
        "$ts" "${mem_used}MB" "${mem_free}MB" "${mem_avail}MB" "${swap_used}MB" "+${delta_fault}"
    
    # Guardar no CSV
    echo "$ts,$mem_total,$mem_used,$mem_free,$mem_avail,$swap_used,$pgfault,$pgmajfault,$pswpin,$pswpout" >> "$LOG_FILE"
    
    sleep "$INTERVAL"
done
