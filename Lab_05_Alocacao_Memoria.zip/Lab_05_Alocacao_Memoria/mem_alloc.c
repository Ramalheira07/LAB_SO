/* ============================================================
 * LAB: Gestão de Memória - Exercício em C
 * Demonstra: malloc, mmap, stack vs heap, fragmentação
 * Compilar: gcc -o mem_alloc mem_alloc.c -Wall
 * ============================================================ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/resource.h>

#define MB (1024*1024)

void print_memory_usage(const char *label) {
    FILE *f = fopen("/proc/self/status", "r");
    char line[128];
    printf("\n  [%s]\n", label);
    while (fgets(line, 128, f)) {
        if (strncmp(line, "VmRSS", 5) == 0 ||
            strncmp(line, "VmSize", 6) == 0 ||
            strncmp(line, "VmPeak", 6) == 0)
            printf("    %s", line);
    }
    fclose(f);
}

void demo_stack_vs_heap() {
    printf("\n========== [1] STACK vs HEAP ==========\n");
    
    int stack_var = 42;
    int *heap_var = malloc(sizeof(int));
    *heap_var = 42;
    
    printf("  Stack var endereço: %p\n", (void*)&stack_var);
    printf("  Heap  var endereço: %p\n", (void*)heap_var);
    printf("  Diferença aproximada: %ld MB\n",
           (long)((char*)&stack_var - (char*)heap_var) / MB);
    
    free(heap_var);
}

void demo_alocacao_grande() {
    printf("\n========== [2] ALOCAÇÃO GRADUAL ==========\n");
    print_memory_usage("Antes de alocar");
    
    char *blocos[5];
    for (int i = 0; i < 5; i++) {
        blocos[i] = malloc(50 * MB);
        if (!blocos[i]) { printf("  ERRO: malloc falhou!\n"); break; }
        memset(blocos[i], 0xAB, 50 * MB); // Forçar alocação física
        printf("  Alocado bloco %d (50MB em %p)\n", i+1, blocos[i]);
    }
    
    print_memory_usage("Após alocar 250MB");
    
    for (int i = 0; i < 5; i++) free(blocos[i]);
    print_memory_usage("Após libertar");
}

void demo_fragmentacao() {
    printf("\n========== [3] FRAGMENTAÇÃO ==========\n");
    
    int N = 100;
    char **ptrs = malloc(N * sizeof(char*));
    
    // Alocar muitos blocos pequenos
    for (int i = 0; i < N; i++)
        ptrs[i] = malloc(1024); // 1KB cada
    
    print_memory_usage("100 blocos x 1KB alocados");
    
    // Libertar apenas os pares (fragmentação)
    for (int i = 0; i < N; i += 2)
        free(ptrs[i]);
    
    print_memory_usage("50 blocos libertados (pares) - memória fragmentada");
    
    // Tentar alocar bloco grande (pode falhar por fragmentação)
    char *big = malloc(60 * 1024);
    printf("  Tentar alocar 60KB contíguo após fragmentação: %s\n",
           big ? "SUCESSO" : "FALHOU");
    if (big) free(big);
    
    for (int i = 1; i < N; i += 2) free(ptrs[i]);
    free(ptrs);
}

void demo_mmap() {
    printf("\n========== [4] MMAP (Memória Mapeada) ==========\n");
    
    size_t size = 10 * MB;
    char *mem = mmap(NULL, size, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    
    if (mem == MAP_FAILED) {
        perror("  mmap falhou");
        return;
    }
    
    printf("  mmap de 10MB em: %p\n", mem);
    memset(mem, 0xFF, size);
    printf("  Escrita de 10MB via mmap: OK\n");
    
    // msync - sincronizar com ficheiro (aqui apenas demonstração)
    // madvise - dar dicas ao kernel
    madvise(mem, size, MADV_SEQUENTIAL);
    printf("  madvise(MADV_SEQUENTIAL) aplicado\n");
    
    munmap(mem, size);
    printf("  munmap: memória libertada\n");
}

int main() {
    printf("======================================================\n");
    printf("  DEMO: Alocação de Memória em C no Linux\n");
    printf("  PID: %d\n", getpid());
    printf("  Veja o estado em: /proc/%d/status\n", getpid());
    printf("======================================================\n");
    
    demo_stack_vs_heap();
    demo_alocacao_grande();
    demo_fragmentacao();
    demo_mmap();
    
    printf("\n====================================================\n");
    printf("  [EXERCÍCIO C]\n");
    printf("  1. Modifique N para 1000 blocos e observe a fragmentação\n");
    printf("  2. Use valgrind ./mem_alloc para detectar memory leaks\n");
    printf("  3. Adicione um malloc() sem free() e verifique com valgrind\n");
    printf("====================================================\n");
    
    return 0;
}
