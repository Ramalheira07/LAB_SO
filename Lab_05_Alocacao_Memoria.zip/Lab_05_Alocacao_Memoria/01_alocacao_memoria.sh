#!/bin/bash
# ============================================================
# LAB: Gestão de Memória no Linux - Script 1
# Tópico: Introdução à Alocação de Memória
# Disciplina: Sistemas Operativos | Engenharia Informática
# ============================================================

echo "======================================================"
echo " LABORATÓRIO: ALOCAÇÃO DE MEMÓRIA NO LINUX"
echo "======================================================"
echo ""

# --- 1. Informações gerais de memória ---
echo "[1] Resumo de Memória do Sistema (free -h)"
echo "------------------------------------------------------"
free -h
echo ""

# --- 2. Detalhes do /proc/meminfo ---
echo "[2] Detalhes de /proc/meminfo (campos principais)"
echo "------------------------------------------------------"
grep -E "MemTotal|MemFree|MemAvailable|Buffers|Cached|SwapTotal|SwapFree|Dirty|Mapped|Shmem|VmallocTotal|VmallocUsed" /proc/meminfo
echo ""

# --- 3. Uso por processo (top 10) ---
echo "[3] Top 10 processos por uso de memória RSS"
echo "------------------------------------------------------"
ps aux --sort=-%mem | awk 'NR<=11 {printf "%-10s %-8s %-8s %s\n", $1, $2, $4"%", $11}'
echo ""

# --- 4. Zonas de memória ---
echo "[4] Zonas de memória do kernel (/proc/buddyinfo)"
echo "------------------------------------------------------"
cat /proc/buddyinfo
echo ""

# --- 5. Estatísticas de NUMA/VM ---
echo "[5] Estatísticas do VM (/proc/vmstat - campos selecionados)"
echo "------------------------------------------------------"
grep -E "pgfault|pgmajfault|pswpin|pswpout|pgpgin|pgpgout|nr_free_pages|nr_anon_pages|nr_mapped" /proc/vmstat
echo ""

# --- 6. Mapa de memória do processo atual ---
echo "[6] Mapa de memória deste processo (PID: $$)"
echo "------------------------------------------------------"
cat /proc/$$/maps | head -20
echo "  ... (truncado a 20 linhas)"
echo ""

echo "======================================================"
echo " [EXERCÍCIO 1] Responda às seguintes questões:"
echo "======================================================"
echo "  a) Qual é a memória RAM total do sistema?"
echo "  b) Qual a diferença entre MemFree e MemAvailable?"
echo "  c) Qual processo consome mais memória RSS?"
echo "  d) O que representam as colunas no /proc/buddyinfo?"
echo "======================================================"
