#!/usr/bin/env python3
"""
============================================================
LAB: Gestão de Memória - Simulador de Substituição de Páginas
Algoritmos: FIFO, LRU, LFU, Óptimo (OPT), Clock
============================================================
"""

from collections import deque, Counter, OrderedDict

# ─────────────────────────────────────────────
# Algoritmo FIFO
# ─────────────────────────────────────────────
def fifo(pages, frames):
    memory = deque()
    faults, trace = 0, []
    for p in pages:
        hit = p in memory
        if not hit:
            faults += 1
            if len(memory) == frames:
                memory.popleft()
            memory.append(p)
        trace.append((p, list(memory), "HIT" if hit else "FAULT"))
    return faults, trace

# ─────────────────────────────────────────────
# Algoritmo LRU (Least Recently Used)
# ─────────────────────────────────────────────
def lru(pages, frames):
    memory = OrderedDict()
    faults, trace = 0, []
    for p in pages:
        if p in memory:
            memory.move_to_end(p)
            trace.append((p, list(memory.keys()), "HIT"))
        else:
            faults += 1
            if len(memory) == frames:
                memory.popitem(last=False)
            memory[p] = True
            trace.append((p, list(memory.keys()), "FAULT"))
    return faults, trace

# ─────────────────────────────────────────────
# Algoritmo LFU (Least Frequently Used)
# ─────────────────────────────────────────────
def lfu(pages, frames):
    memory, freq, faults, trace = set(), Counter(), 0, []
    for p in pages:
        freq[p] += 1
        if p in memory:
            trace.append((p, sorted(memory), "HIT"))
        else:
            faults += 1
            if len(memory) == frames:
                # Remover o menos frequentemente usado
                evict = min(memory, key=lambda x: freq[x])
                memory.remove(evict)
            memory.add(p)
            trace.append((p, sorted(memory), "FAULT"))
    return faults, trace

# ─────────────────────────────────────────────
# Algoritmo Óptimo (OPT / Bélády)
# ─────────────────────────────────────────────
def optimal(pages, frames):
    memory, faults, trace = [], 0, []
    for i, p in enumerate(pages):
        if p in memory:
            trace.append((p, list(memory), "HIT"))
        else:
            faults += 1
            if len(memory) < frames:
                memory.append(p)
            else:
                # Encontrar a página que não será usada por mais tempo
                future_use = {}
                for m in memory:
                    try:
                        future_use[m] = pages[i+1:].index(m)
                    except ValueError:
                        future_use[m] = float('inf')
                evict = max(future_use, key=future_use.get)
                memory[memory.index(evict)] = p
            trace.append((p, list(memory), "FAULT"))
    return faults, trace

# ─────────────────────────────────────────────
# Algoritmo Clock (Segunda Chance)
# ─────────────────────────────────────────────
def clock(pages, frames):
    memory = [None] * frames
    use_bit = [0] * frames
    pointer = 0
    faults, trace = 0, []
    
    for p in pages:
        # Verificar se página está em memória
        if p in memory:
            idx = memory.index(p)
            use_bit[idx] = 1
            trace.append((p, [m for m in memory if m], "HIT"))
        else:
            faults += 1
            # Procurar frame para substituir
            while use_bit[pointer] == 1:
                use_bit[pointer] = 0
                pointer = (pointer + 1) % frames
            memory[pointer] = p
            use_bit[pointer] = 1
            pointer = (pointer + 1) % frames
            trace.append((p, [m for m in memory if m], "FAULT"))
    return faults, trace

# ─────────────────────────────────────────────
# Demonstrar Anomalia de Bélády (FIFO)
# ─────────────────────────────────────────────
def belady_anomaly():
    print("\n" + "="*60)
    print("  ANOMALIA DE BÉLÁDY (FIFO)")
    print("="*60)
    seq = [1,2,3,4,1,2,5,1,2,3,4,5]
    print(f"  Sequência: {seq}")
    print()
    for f in range(3, 7):
        faults, _ = fifo(seq, f)
        print(f"  Frames={f}: {faults} page faults")
    print("\n  NOTA: Com 4 frames pode ter MAIS faults que com 3! (Bélády)")

# ─────────────────────────────────────────────
# Imprimir trace detalhado
# ─────────────────────────────────────────────
def print_trace(name, trace, faults):
    print(f"\n{'─'*55}")
    print(f"  Algoritmo: {name}  |  Total Page Faults: {faults}")
    print(f"{'─'*55}")
    print(f"  {'Pág':<6} {'Memória':<30} {'Estado'}")
    print(f"  {'───':<6} {'───────':<30} {'──────'}")
    for page, mem, status in trace:
        mem_str = str(mem)
        marker = " ◄" if status == "FAULT" else ""
        print(f"  {page:<6} {mem_str:<30} {status}{marker}")

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
if __name__ == "__main__":
    print("="*60)
    print("  SIMULADOR DE SUBSTITUIÇÃO DE PÁGINAS")
    print("  Engenharia Informática - Sistemas Operativos")
    print("="*60)

    # Sequência de referência clássica (Silberschatz OS textbook)
    ref_sequence = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
    FRAMES = 3

    print(f"\n  Sequência de referência: {ref_sequence}")
    print(f"  Número de frames: {FRAMES}")
    print("\n  ┌─────────────┬──────────────┐")
    print(  "  │  Algoritmo  │ Page Faults  │")
    print(  "  ├─────────────┼──────────────┤")
    
    algos = [
        ("FIFO",    fifo(ref_sequence, FRAMES)),
        ("LRU",     lru(ref_sequence, FRAMES)),
        ("LFU",     lfu(ref_sequence, FRAMES)),
        ("Óptimo",  optimal(ref_sequence, FRAMES)),
        ("Clock",   clock(ref_sequence, FRAMES)),
    ]
    
    for name, (faults, _) in algos:
        print(f"  │ {name:<11} │ {faults:<12} │")
    print("  └─────────────┴──────────────┘")

    # Trace detalhado do LRU
    print("\n[Trace detalhado - LRU]")
    faults_lru, trace_lru = lru(ref_sequence, FRAMES)
    print_trace("LRU", trace_lru, faults_lru)

    # Demonstrar anomalia de Bélády
    belady_anomaly()

    print("\n" + "="*60)
    print("  EXERCÍCIOS:")
    print("="*60)
    print("  1. Altere ref_sequence e FRAMES e re-execute")
    print("  2. Implemente o algoritmo NRU (Not Recently Used)")
    print("  3. Encontre uma sequência que cause anomalia de Bélády")
    print("  4. Compare Clock vs LRU para sequências longas")
    print("="*60)
