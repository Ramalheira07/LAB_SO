import os
import signal
import sys

def handle_exit(sig, frame):
    print(f"\nEncerrando processo {os.getpid()}...")
    sys.exit(0)

# Permite encerrar o script suavemente com Ctrl+C
signal.signal(signal.SIGINT, handle_exit)

def heavy_computation():
    print(f"Processo iniciado! PID: {os.getpid()}")
    print("Executando cálculos intensivos...")
    # Loop infinito de processamento puro
    count = 0
    while True:
        count += 1
        # Operação simples para manter a CPU ocupada
        _ = count * count

if __name__ == "__main__":
    heavy_computation()